
data <- read.csv(file="DataJawaTengah.csv", header=TRUE, sep=",")
data

model <-lm(RumahTanggaPertanian ~ PerusahaanPertanian, data=data)
summary(model)

plot(RumahTanggaPertanian ~ PerusahaanPertanian, data=data)
abline(model, col = "red", lwd = 1)

poly_model <- lm(Tanamanpadipalawija ~ poly(TanamanPerkebunan,degree=2), data = data)
summary(poly_model)

x <- with(data, seq(min(TanamanPerkebunan), max(TanamanPerkebunan), length.out=2000))
y <- predict(poly_model, newdata = data.frame(TanamanPerkebunan = x))

plot(Tanamanpadipalawija ~ TanamanPerkebunan, data = data)
lines(x, y, col = "red")
